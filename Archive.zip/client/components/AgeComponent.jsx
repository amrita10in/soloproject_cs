import React from "react";
import {useState} from "react";
import { useSelector } from "react-redux";


const AgeComponent = () => {
  const [currentAge, setAge] = useState(null);
  const [name, setName] = useState("");

  const calculateAge = () => {
    const childName = document.getElementById('addName').value;
    const dateOfBirth = document.getElementById('addBirth').value;

    const [month, day, year] = dateOfBirth.split('/').map(Number);
    const birthDate = new Date(year, month - 1, day);
    const today = new Date();
    const yearsDiff = today.getFullYear() - birthDate.getFullYear();
    const monthsDiff = today.getMonth() - birthDate.getMonth();
    let ageInMonths = yearsDiff * 12 + monthsDiff;
    if (today.getDate() < birthDate.getDate()) {
      ageInMonths--;
    }

    setAge(ageInMonths);
    setName(childName);
  }

  return (
    <div className="ageCard">
      <p><label id= "name">Please enter your child's name:</label></p>
      <input type="text" id="addName"></input>
      <p><label id="age">Please enter your child's date of birth</label></p>
      <input type="text" placeholder="mm/dd/yyyy" id="addBirth"></input>
      <p><button type= "button" onClick = {calculateAge}>Submit</button></p>
      <p>{currentAge ? `${name} is ${currentAge} months old`: ""}</p>
    </div>
  );
};

export default AgeComponent;
