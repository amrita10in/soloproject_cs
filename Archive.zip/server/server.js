const express = require('express');
const path = require('path');
const mongoose = require('mongoose');


const userController = require('./controllers/userController');

// const mongoURI = process.env.NODE_ENV === 'test' ? 'mongodb://localhost/unit11test' : 'mongodb://localhost/unit11dev';
// mongoose.connect(mongoURI);


const PORT = 3000;

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(express.static(path.join(__dirname, '..', 'dist')));


app.post('/signup', userController.createUser, (req, res) => {
  return res.status(200).json({message: 'Data posted successfully'});
});

app.get('*', (req,res) => {
  res.sendFile(path.join(__dirname, '..', 'dist', 'index.html'));
});


// app.use('*', (req,res) => {
//   res.status(404).send('Not Found');
// });

/**
 * Global error handler
 */
app.use((err, req, res, next) => {
  console.log(err);
  res.status(500).send({ error: err });
});

app.listen(PORT, ()=>{ console.log(`Listening on port ${PORT}...`); });

module.exports = app;
