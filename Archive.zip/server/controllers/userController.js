const User = require('../models/userModel');


const userController = {};


userController.createUser = async (req, res, next) => {
  console.log("I am here");
  const {username, password, childName, childDOB} = req.body;
  console.log(req.body);
  if(typeof username !== 'string' || typeof  password !== 'string' || typeof childName !== 'string' || typeof childDOB !== 'Number'){
    return next ({
      log: 'Error in usercontroller.createUser: ',
      Status: 400,
      message: { err: 'Input is in incorrect format' },
    })
  }
  try {
    const newUser = new User({username, password, childName, childDOB});
    await User.collection.insertOne(newUser);
    console.log('User created successfully:', newUser);
    return next();
  } catch (err){
    return next('Error in userController.creafeUser: ' + JSON.stringify(err));
  }
}

module.exports = userController;